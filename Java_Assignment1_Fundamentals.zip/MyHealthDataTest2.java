/*
* Student Name: Ethan EG
* Lab Professor: Professor George Kriger
* Due Date: 2023/02/24
* Modified: 2023/02/21
* Description: Assignment 1: Patient.java - 23W CST8284
*/

import org.junit.Assert;
import org.junit.Test;

/**
 * this test class uses junit to test the Patient class's getBMI() method.
 * @author ethan
 *
 */
public class MyHealthDataTest2 {

	   /**
	 * Because of slight errors when rounding this constant gives wiggle room when comparing values.
	 */
	private static final double EPSILON = 1E-12;
	
	/**
	 * this test uses the right expected value to demonstrate a successful test return statement. 
	 * The correct expected value was calculated twice (just to be sure) using the formula on a 
	 * calculator.
	 */
	@Test
	public void testGetBMI1() {
		Patient aPatient = new Patient();
		aPatient.setHeight(75);
		aPatient.setWeight(175);
		double expected = 21.87;
		Assert.assertEquals(expected, aPatient.getBMI(), 0.005);
   }	
	
	/**
	 * this test uses the wrong expected value to demonstrate a wrong test return statement
	 */
	@Test
	public void testGetBMI2() {
		Patient aPatient = new Patient();
		aPatient.setHeight(50);
		aPatient.setWeight(125);
		//the actual expected value -> double expected = 35.15;
		double expected = 53.51;
		Assert.assertEquals(expected, aPatient.getBMI(), 0.005);
   }	
}
