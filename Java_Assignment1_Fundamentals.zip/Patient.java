/*
* Student Name: Ethan EG
* Lab Professor: Professor George Kriger
* Due Date: 2023/02/24
* Modified: 2023/02/21
* Description: Assignment 1: Patient.java - 23W CST8284
*/

//This system maintains important health information about a patient.

//used to calculate age
import java.time.Year;

/**
 * The Patient class maintains important health information about a patient.
 * @author Ethan EG
 */
public class Patient {

	// declarations for patient information
    /**
     * The first name of the patient.
     */
    private String firstName;
    
    /**
     * The last name of the patient.
     */
    private String lastName;
    
    /**
     * The gender of the patient.
     */
    private String gender;
    
    /**
     * The birth year of the patient.
     */
    private int birthYear;
    
    /**
     * The birth month of the patient.
     */
    private int birthMonth;
    
    /**
     * The birth day of the patient.
     */
    private int birthDay;
    
    /**
     * The height of the patient in meters.
     */
    private double height;
    
    /**
     * The weight of the patient in kilograms.
     */
    private double weight;

	/**
	 * Constructor for the Patient class
	 * 
	 * @param firstName  The patient's first name
	 * @param lastName   The patient's last name
	 * @param gender     The patient's gender
	 * @param birthYear  The year of the patient's birth
	 * @param birthMonth The month of the patient's birth
	 * @param birthDay   The day of the patient's birth
	 * @param height     The patient's height in inches
	 * @param weight     The patient's weight in pounds
	 */
	public Patient(String firstName, String lastName, String gender, int birthYear, int birthMonth, int birthDay,
			double height, double weight) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.birthYear = birthYear;
		this.birthMonth = birthMonth;
		this.birthDay = birthDay;
		this.height = height;
		this.weight = weight;
	}

	/**
	 * Default constructor for the Patient class
	 */
	public Patient() {
		this.firstName = "";
		this.lastName = "";
		this.gender = "";
		this.birthYear = 0;
		this.birthMonth = 0;
		this.birthDay = 0;
		this.height = 0.0;
		this.weight = 0.0;
	}

	// getters and setters for patient information
	/**
	 * Getter method for the patient's first name
	 * 
	 * @return The patient's first name
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Setter method for the patient's first name
	 * 
	 * @param firstName The patient's first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Getter method for the patient's last name
	 * 
	 * @return The patient's last name
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Setter method for the patient's last name
	 * 
	 * @param lastName The patient's last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Getter method for the patient's gender
	 * 
	 * @return The patient's gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * Setter method for the patient's gender
	 * 
	 * @param gender The patient's gender
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * Getter method for the patient's birth year
	 * 
	 * @return The patient's birth year
	 */
	public int getBirthYear() {
		return birthYear;
	}

	/**
	 * Setter method for the patient's birth year
	 * 
	 * @param birthYear The year of the patient's birth
	 */
	public void setBirthYear(int birthYear) {
		this.birthYear = birthYear;
	}

	/**
	 * Getter method for the patient's birth month
	 * 
	 * @return The patient's birth month
	 */
	public int getBirthMonth() {
		return birthMonth;
	}

	/**
	* Setter method for the patient's birth month
	*
	* @param birthMonth The patient's birth month to set
	*/
	public void setBirthMonth(int birthMonth) {
		this.birthMonth = birthMonth;
	}
	
	/**
	 * Getter method for the patient's birth day
	 * 
	 * @return The patient's birth day
	 */
	public int getBirthDay() {
		return birthDay;
	}
	
	/**
	 * Setter method for the patient's birth day
	 * 
	 * @param birthDay The patient's birth day to set
	 */
	public void setBirthDay(int birthDay) {
		this.birthDay = birthDay;
	}
	
	/**
	 * Getter method for the patient's height
	 * 
	 * @return The patient's height
	 */
	public double getHeight() {
		return height;
	}
	
	/**
	 * Setter method for the patient's height
	 * 
	 * @param height The patient's height to set
	 */
	public void setHeight(double height) {
		this.height = height;
	}
	
	/**
	 * Getter method for the patient's weight
	 * 
	 * @return The patient's weight
	 */
	public double getWeight() {
		return weight;
	}
	
	/**
	 * Setter method for the patient's weight
	 * 
	 * @param weight The patient's weight to set
	 */
	public void setWeight(double weight) {
		this.weight = weight;
	} 
	
	/**
	 * Calculates the patient's age based on their birth year
	 * 
	 * @return The patient's age
	 */
	public int getAge(){
		return Year.now().getValue()-birthYear;
	}
	
	/**
	 * Calculates the patient's maximum heart rate based on their age
	 * 
	 * @return The patient's maximum heart rate
	 */
	public int getMaximumHeartRate(){
		return 220-getAge();
	}
	
	/**
	 * Calculates the patient's target heart rate range based on their maximum heart rate
	 * 
	 * @return The patient's target heart rate range
	 */
	public double getTargetHeartRateRange() {
		return ((getMaximumHeartRate()*0.85)+(getMaximumHeartRate()/2))/2;
	}
	
	/**
	 * Calculates the patient's Body Mass Index (BMI) based on their weight and height
	 * 
	 * @return The patient's BMI
	 */
	public double getBMI(){
	   return (getWeight() * 703) / (getHeight() * getHeight());
	} 
	
	/**
	 * Displays the patient's health data including their name, gender, birth date, height, weight, age, maximum heart rate, target heart rate range, and BMI
	 */
	public void displayMyHealthData(){ 
		
	   System.out.printf("Patient information:%nName: %s %s%nGender: %s%nBirthDate: %d/%d/%d%nHeight: %.2f%nWeight: %.2f%nAge: %d%nMaximum Heart Rate: %d%nTarget Heart Rate: %.2f%nBMI: %.2f%n%n", 
	   firstName, lastName, gender, birthYear, birthMonth, birthDay, height, weight, getAge(), getMaximumHeartRate(), getTargetHeartRateRange(), getBMI());
		
	   System.out.println("BMI VALUES");
	   System.out.println("Underweight: less than 18.5");
	   System.out.println("Normal:      between 18.5 and 24.9");
	   System.out.println("Overweight:  between 25 and 29.9");
	   System.out.println("Obese:       30 or greater");   
	   System.out.println("Obese:       30 or greater");   
	   
	   System.out.printf("%nProgram By Ethan EG");
	}

} // end class Patient