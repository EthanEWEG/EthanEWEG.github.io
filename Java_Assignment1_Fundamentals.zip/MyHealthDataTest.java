/*
* Student Name: Ethan EG
* Lab Professor: Professor George Kriger
* Due Date: 2023/02/24
* Modified: 2023/02/21
* Description: Assignment 1: Patient.java - 23W CST8284
*/

import java.util.Scanner;

/**
 * This class is a test driver for the Patient class, which collects and displays patient information.
 * @author Ethan EG
 */
public class MyHealthDataTest {
	
	/**
	 * The reference to Scanner for user input.
	 */
	private static Scanner sc;

	/**
	 * The main method of the class, which collects user inputs for patient information and displays the result.
	 *
	 * @param args The main arguments for the driver.
	 */
	public static void main(String[]args) {
		
		//constructors
		sc = new Scanner(System.in);
		Patient patient = new Patient();
		
		//user inputs
		System.out.print("Enter patient first name: ");
        String firstName = sc.nextLine();
        patient.setFirstName(firstName);
        
        System.out.print("Enter patient last name: ");
        String lastName = sc.nextLine();
        patient.setLastName(lastName);
        
        System.out.print("Enter patient gender: ");
        String gender = sc.nextLine();
        patient.setGender(gender);
        
        System.out.print("Enter patient birth year: ");
        int birthYear = sc.nextInt();
        patient.setBirthYear(birthYear);
        
        System.out.print("Enter patient birth month: ");
        int birthMonth = sc.nextInt();
        patient.setBirthMonth(birthMonth);
        
        System.out.print("Enter patient birth day: ");
        int birthDay = sc.nextInt();
        patient.setBirthDay(birthDay);
        
        System.out.print("Enter patient height (in inches): ");
        double height = sc.nextDouble();
        patient.setHeight(height);
        
        System.out.print("Enter patient weight (in pounds): ");
        double weight = sc.nextDouble();
        patient.setWeight(weight);
        
        //display patient info
        patient.displayMyHealthData();
	}
}
