/*
* Student Name: Ethan EG
* Lab Professor: Professor Zeinab Bayati
* Due Date: 2023/03/17
* Modified: 2023/03/17
* Description: Lab 5
*/

import java.util.Random;

/**
 * This program is the part B for lab 5. Using up to 100 max agents and an age range from 20 to 65 the program randomly
 * prints multiple different random combinations of agent/chief/supervisor information using polymorphism.
 * @author ethan
 *
 */
public class SalesAgentTest2PartB {
	 /**
	 * maximum number of agents as a constant class variable
	 */
    public static final int MAX_AGENTS = 100;
    /**
     * Minimum agent age
     */
    public static final int MIN_AGE = 20;
    /**
     * Maximum agent age
     */
    public static final int MAX_AGE = 65;
    
    /**
     * Main method for testing displaying 100 agents/supervisors/chiefs with different random information
     * using polymorphism
     * @param args command line arguments
     */
    public static void main(String[] args) {
        SalesAgent[] agents = new SalesAgent[MAX_AGENTS];
        Random rand = new Random();

        // create agents with random ages
        for (int i = 0; i < agents.length; i++) {
            String name = "Agent " + (i + 1);
            int age = rand.nextInt(MAX_AGE - MIN_AGE + 1) + MIN_AGE;
            if (i % 3 == 0) {
                agents[i] = new SalesSupervisor(name, age, "Toronto");
            } else if (i % 5 == 0) {
                agents[i] = new SalesChief(name, age, "Ottawa", "Sales");
            } else {
                agents[i] = new SalesAgent(name, age);
            }
        }

        // print all agents using polymorphism
        for (SalesAgent agent : agents) {
            if (agent != null) {
                System.out.println(agent);
            }
        }
    }
}