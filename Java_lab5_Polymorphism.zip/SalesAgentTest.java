/*
* Student Name: Ethan EG
* Lab Professor: Professor Zeinab Bayati
* Due Date: 2023/03/17
* Modified: 2023/03/17
* Description: Lab 5
*/

/**
 * This program is the first test for the SalesAgent class including the subclass. 
 * @author ethan
 *
 */
public class SalesAgentTest
{  
   /**
 * main method used to test sales agent
 * @param args command line arguments
 */
public static void main(String[] args)
   {

	//... your code starts here!
	   // 1- create 2 sales agents, one sales supervisor, and one sales chief.
	   //2-  print all created objects
	   
	   SalesAgent salesAgent = new SalesAgent("Peter",56);
	   SalesAgent salesAgent2 = new SalesAgent("John",48);
	   SalesSupervisor salesSupervisor = new SalesSupervisor("Ifeoma",53,"Toronto");
	   SalesChief salesChief = new SalesChief("EthanEG",35,"Ottawa","Sales");
	   
	   System.out.println(salesAgent.toString());
	   System.out.println(salesAgent2.toString());
	   System.out.println(salesSupervisor.toString());
	   System.out.println(salesChief.toString());
   }
}  