/*
* Student Name: Ethan EG
* Lab Professor: Professor Zeinab Bayati
* Due Date: 2023/03/17
* Modified: 2023/03/17
* Description: Lab 5
*/

/**
 * This class extends from SalesAgent and is used to add the location to the string output. 
 * This is a demonstration of polymorphism
 * @author ethan
 *
 */
public class SalesSupervisor extends SalesAgent{

    /**
     * SalesSupervisor Object Constructor 
     * @param n Agent name
     * @param s Agent age
     * @param l Supervisor location
     */
    public SalesSupervisor(String n, int s, String l) {
        super(n, s);
        location = l;
    }

    /**
	 * Supervisor location
	 */
	private String location;
	
	
	/**
	 * Method returns a string representation of the object.
     * @return a string representation of the object
	 */
	public String toString(){
		return "Sales Supervisor [super=" + super.toString() + ",location="+location+"]";
	}

}
