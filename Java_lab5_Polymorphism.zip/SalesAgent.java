/*
* Student Name: Ethan EG
* Lab Professor: Professor Zeinab Bayati
* Due Date: 2023/03/17
* Modified: 2023/03/17
* Description: Lab 5
*/

// This is CST 8284 Lab 5. Follow all instructions stated in your Lab slides carefully.
// Include all the items required in this class.

/**
 * This class shows a Sales Agent with a name and age.
 * @author ethan
 *
 */
public class SalesAgent
{  
   /**
 * Agents Name
 */
private String name;
   /**
 * Agents Age
 */
private int age;

   /**
      SalesAgent object constructor 
      @param n the name of the Sales Agent
      @param a the age of the Sales Agent
   */
   public SalesAgent(String n, int a) {
       name = n;
       age = a;
   }
   

   /**
      Method returns a string representation of the object.
      @return a string representation of the object
   */
   public String toString()
   {  
      return "Sales Agent [name=" + name + ",age=" + age + "]";
   }
}