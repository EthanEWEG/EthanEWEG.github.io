/*
* Student Name: Ethan EG
* Lab Professor: Professor Zeinab Bayati
* Due Date: 2023/03/17
* Modified: 2023/03/17
* Description: Lab 5
*/


/**
 * This class extends from SalesSupervisor which extends from SalesAgent and is used to add the 
 * location to the string output. This is another demonstration of polymorphism
 * @author ethan
 *
 */
public class SalesChief extends SalesSupervisor{
	
	
	/**
	 * SalesChief object constructor 
	 * @param n Agent name
	 * @param s Agent Age
	 * @param l Supervisor Location
	 * @param d Chief Department
	 */
	public SalesChief(String n, int s, String l, String d) {
		super(n, s, l);
		department = d;
	}

	/**
	 * Chief department 
	 */
	private String department;
	
	/**
	 * Method returns a string representation of the object.
     * @return a string representation of the object
	 */
	public String toString(){
		return "Sales Chief [super=" + super.toString() + ",department="+department+"]";
	}
	
}
