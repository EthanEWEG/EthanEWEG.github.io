/*
* Student Name: Ethan EG
* Lab Professor: Professor Zeinab Bayati
* Due Date: 2023/03/17
* Modified: 2023/03/17
* Description: Lab 5
*/

/**
 * This program is the tests for the SalesAgent class including the subclasses.
 * @author ethan
 *
 */
public class SalesAgentTest2
{  
   /**
 * maximum number of agents as a constant class variable
 */
private static final int MAX_AGENTS = 4;
	
   /**
 * main method used to test SalesAgent
 * @param args command line arguments
 */
public static void main(String[] args)
   {
	   
	// Create an array of SalesAgent objects with maximum capacity
	   SalesAgent[] agents = new SalesAgent[MAX_AGENTS];
	   
       // Create SalesAgent objects and add them to the array
       agents[0] = new SalesAgent("Peter", 56);
       agents[1] = new SalesAgent("John", 48);
       agents[2] = new SalesSupervisor("Ifeoma", 53, "Toronto");
       agents[3] = new SalesChief("EthanEG", 35, "Ottawa", "Sales");
       
       /* Print all sales agents using polymorphism. This for loop also allows flexibility for the MAX_AGENTS to be changed
       whenever needed */
       for (int i = 0; i < agents.length; i++) {
           System.out.println("Agent #" + (i+1) + ": " + agents[i].toString());
       }
   }
}  